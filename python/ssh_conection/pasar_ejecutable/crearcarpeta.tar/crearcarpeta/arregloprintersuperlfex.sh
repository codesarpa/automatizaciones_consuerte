#!/bin/bash
# Script idempotente para restringir reimpresión de documentos en CUPS (Ubuntu 16.04)

echo "==> Verificando configuración actual de CUPS..."
# Verificar PreserveJobHistory
CURRENT_HISTORY=$(cupsctl | grep -o "PreserveJobHistory=[^ ]*" | cut -d= -f2)
if [ "$CURRENT_HISTORY" == "no" ]; then
    echo "   -> PreserveJobHistory ya está en 'no'."
else
    echo "   -> Cambiando PreserveJobHistory a 'no'..."
    sudo cupsctl PreserveJobHistory=no
fi

# Verificar PreserveJobFiles
CURRENT_FILES=$(cupsctl | grep -o "PreserveJobFiles=[^ ]*" | cut -d= -f2)
if [ "$CURRENT_FILES" == "no" ]; then
    echo "   -> PreserveJobFiles ya está en 'no'."
else
    echo "   -> Cambiando PreserveJobFiles a 'no'..."
    sudo cupsctl PreserveJobFiles=no
fi

# Verificar impresora y política de error
PRINTER=$(lpstat -p | awk '{print $2}' | head -n 1)
if [ -n "$PRINTER" ]; then
    CURRENT_POLICY=$(lpoptions -p "$PRINTER" -l 2>/dev/null | grep -i "printer-error-policy" | grep "" | cut -d"" -f2 | tr -d " ")
    if [ "$CURRENT_POLICY" == "abort-job" ]; then
        echo "   -> La impresora $PRINTER ya tiene la política de error 'abort-job'."
    else
        echo "   -> Configurando política de error de la impresora $PRINTER a 'abort-job'..."
        sudo lpadmin -p "$PRINTER" -o printer-error-policy=abort-job
    fi
else
    echo "   -> No se detectó impresora instalada. Puedes configurar manualmente después."
fi

# Reiniciar CUPS solo si hubo cambios
if [ "$CURRENT_HISTORY" != "no" ] || [ "$CURRENT_FILES" != "no" ] || [ "$CURRENT_POLICY" != "abort-job" ]; then
    echo "==> Reiniciando servicio CUPS para aplicar cambios..."
    sudo systemctl restart cups
else
    echo "==> No hubo cambios. No es necesario reiniciar CUPS."
fi

echo "==> Configuración de CUPS comprobada/completada."
