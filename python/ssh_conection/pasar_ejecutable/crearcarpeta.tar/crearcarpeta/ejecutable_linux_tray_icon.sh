#!/bin/bash

echo "Iniciando script..."

# Obtener el directorio del usuario actual
usuario="$HOME"

# Definir las rutas
ruta_origen="$usuario/Documentos/Try_icon/actualizaciones/superflex-tray-icon.jar"
ruta_destino="$usuario/Documentos/Try_icon"

# Verificar si el archivo existe en la carpeta de actualizaciones
if [ -f "$ruta_origen" ]; then
    echo "Archivo encontrado. Moviendo a la carpeta destino..."

    mv "$ruta_origen" "$ruta_destino"
    if [ $? -ne 0 ]; then
        echo "Error: No se pudo mover el archivo."
        read -p "Presiona Enter para salir..."
        exit 1
    fi

    echo "Archivo movido exitosamente a $ruta_destino."
else
    echo "No se encontraron actualizaciones."
fi

# --- Ejecutar el JAR ---
echo "Iniciando la aplicación..."

sudo java -Xmx256m -jar /home/gamble/Documentos/Try_icon/superflex-tray-icon.jar -u gamble &

echo "Script terminado. Presiona Enter para salir..."
read
