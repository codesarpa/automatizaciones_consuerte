#!/bin/bash
echo ">>> Ejecutando script2.sh"
uname -a
