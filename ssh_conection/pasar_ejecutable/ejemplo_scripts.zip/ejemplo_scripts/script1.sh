#!/bin/bash
echo ">>> Ejecutando script1.sh"
date